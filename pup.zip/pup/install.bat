@echo off
REM Install pup command

set "PUP_DIR=%~dp0"

echo @echo off > "%PUP_DIR%pup.bat"
echo python "%PUP_DIR%editor.py" %%* >> "%PUP_DIR%pup.bat"

setx PATH "%PATH%;%PUP_DIR%" >nul 2>&1

echo.
echo ========================================
echo   pup command installed!
echo.
echo   Run: pup
echo   Or: pup file_path
echo.
echo   Example: pup C:\Users\FSOS\Documents\test\1.txt
echo.
echo   IMPORTANT: Close and reopen terminal
echo   to use pup from any directory!
echo.
pause