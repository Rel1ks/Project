"""
Консольный текстовый редактор (аналог nano)
Создан с использованием библиотеки Textual

Возможности:
- Открытие/сохранение файлов
- Поиск с подсветкой
-Undo/Redo
- Номера строк
- Выделение всего текста
- История предыдущих файлов
"""

# Импорт необходимых модулей из библиотеки Textual
from textual.app import App, ComposeResult
from textual.widgets import TextArea, Static, Footer, Input
from textual.binding import Binding
from textual.widgets.text_area import Selection
from textual.screen import ModalScreen
from textual.containers import Container


# ============================================================================
# Диалог открытия/сохранения файла
# ============================================================================
class InputDialog(ModalScreen):
    """
    Модальное окно для ввода пути к файлу.
    Параметры:
        mode: режим работы - "open" (открыть) или "save" (сохранить)
        default: путь по умолчанию (для сохранения)
    """
    def __init__(self, mode: str, default: str = ""):
        super().__init__()
        self.mode = mode  # Режим: open или save
        self.default = default  # Путь по умолчанию

    def compose(self) -> ComposeResult:
        """Создание элементов интерфейса диалога"""
        if self.mode == "open":
            # Диалог открытия файла
            yield Container(
                Static("Open file:", id="prompt"),
                Input(placeholder="Enter file path...", id="dialog-input"),
                id="dialog"
            )
        else:
            # Диалог сохранения файла
            yield Container(
                Static("Save file:", id="prompt"),
                Input(value=self.default, id="dialog-input"),
                id="dialog"
            )

    def on_mount(self):
        """При показе диалога - сфокусировать поле ввода"""
        self.query_one("#dialog-input", Input).focus()

    def on_input_submitted(self, event):
        """Обработка нажатия Enter - передаём путь в главное приложение"""
        app = self.app
        if isinstance(app, EditorApp):
            app._dialog_result = (event.value, self.mode)
            app.set_timer(0.05, app._handle_dialog_result)
        self.app.pop_screen()


# ============================================================================
# Диалог подтверждения (Yes/No)
# ============================================================================
class ConfirmDialog(ModalScreen):
    """
    Модальное окно с выбором Yes/No.
    Используется при выходе с несохранёнными изменениями.
    Параметры:
        message: текст сообщения
    """
    def __init__(self, message: str):
        super().__init__()
        self.message = message

    def compose(self) -> ComposeResult:
        """Создание элементов интерфейса"""
        yield Container(
            Static(self.message, id="prompt"),
            Static("  Yes", id="choice-yes"),
            Static("  No", id="choice-no"),
            id="dialog"
        )

    def on_mount(self):
        """При показе - по умолчанию выбрано No"""
        self.selected = "no"
        self.query_one("#choice-yes").update("  Yes")
        self.query_one("#choice-no").update("> No")

    def on_key(self, event):
        """Обработка клавиш для выбора"""
        # Закрытие диалога по Escape или C
        if event.key in ("escape", "c"):
            self.app.pop_screen()
            return
        # Переключение на Yes (стрелка вверх или влево)
        if event.key in ("up", "left"):
            self.selected = "yes"
            self.query_one("#choice-yes").update("> Yes")
            self.query_one("#choice-no").update("  No")
        # Переключение на No (стрешка вниз или вправо)
        elif event.key in ("down", "right"):
            self.selected = "no"
            self.query_one("#choice-yes").update("  Yes")
            self.query_one("#choice-no").update("> No")
        # Подтверждение выбора по Enter
        elif event.key == "enter":
            app = self.app
            result = "save" if self.selected == "yes" else "quit"
            self.app.pop_screen()
            if isinstance(app, EditorApp):
                app._confirm_result = result
                app.set_timer(0.05, app._handle_confirm_result)


# ============================================================================
# Главное приложение редактора
# ============================================================================
class EditorApp(App):
    """
    Основной класс текстового редактора.
    Содержит все функции и биндинги клавиш.
    """

    # Стили CSS для виджетов
    CSS = """
    Screen { overflow: hidden; }  # Скрываем переполнение экрана
    #filepath { height: 1; dock: top; align: left top; }  # Панель пути файла
    #editor { border: none; }  # Текстовая область без рамки
    #dialog { width: 50; height: auto; background: $surface; border: thick $accent; padding: 1; }  # Стиль диалогов
    """

    # Таблица биндингов (горячих клавиш)
    BINDINGS = [
        Binding("ctrl+o", "open_file", "Open"),  # Открыть файл
        Binding("ctrl+s", "save_file", "Save"),  # Сохранить файл
        Binding("ctrl+f", "toggle_search", "Find", priority=True),  # Поиск
        Binding("ctrl+z", "undo", "Undo"),  # Отменить
        Binding("ctrl+y", "redo", "Redo"),  # Повторить
        Binding("escape", "exit_editor", "Exit", priority=True),  # Выход
        Binding("ctrl+a", "select_all_text", "Select All", priority=True),  # Выделить всё
        Binding("tab", "insert_tab", "Tab", priority=True),  # Табуляция (4 пробела)
        Binding("f1", "previous_file", "Previous"),  # Предыдущий файл
        Binding("f2", "new_file", "New"),  # Новый файл
        Binding("f5", "reload_file", "Reload"),  # Перезагрузить файл
        Binding("ctrl+home", "goto_top", "Top"),  # В начало файла
        Binding("ctrl+end", "goto_bottom", "Bottom"),  # В конец файла
    ]

    # -------------------------------------------------------------------------
    # Действия (actions) - функции, вызываемые по биндингам
    # -------------------------------------------------------------------------

    def action_select_all_text(self):
        """Выделить весь текст (Ctrl+A)"""
        doc = self.editor.document
        self.editor.selection = Selection(doc.start, doc.end)

    def action_goto_top(self):
        """Перейти в начало файла (Ctrl+Home)"""
        self.editor.move_cursor(self.editor.document.start)

    def action_goto_bottom(self):
        """Перейти в конец файла (Ctrl+End)"""
        self.editor.move_cursor(self.editor.document.end)

    def action_previous_file(self):
        """Открыть предыдущий файл (F1)"""
        if self.has_unsaved_changes:
            self.notify("Save current file first")
            return
        if self.previous_file_path:
            try:
                with open(self.previous_file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                # Меняем текущий и предыдущий файл местами
                self.current_file_path, self.previous_file_path = self.previous_file_path, self.current_file_path
                self.file_content, self.previous_file_content = content, self.file_content
                self.editor.load_text(content)
                self.update_title()
            except Exception as e:
                self.notify(f"Error: {e}")
        else:
            self.notify("No previous file")

    def action_new_file(self):
        """Создать новый файл (F2)"""
        if self.has_unsaved_changes:
            self.notify("Unsaved changes! Save first")
            return
        # Сохраняем текущий как предыдущий перед созданием нового
        if self.current_file_path:
            self.previous_file_path = self.current_file_path
            self.previous_file_content = self.file_content
        self.editor.clear()
        self.current_file_path = None
        self.file_content = ""
        self.update_title()

    def action_reload_file(self):
        """Перезагрузить текущий файл (F5)"""
        if self.current_file_path and self.has_unsaved_changes:
            try:
                with open(self.current_file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                self.editor.load_text(content)
                self.file_content = content
                self.notify("Reloaded")
            except Exception as e:
                self.notify(f"Error: {e}")
        else:
            self.notify("No file to reload")

    def action_exit_editor(self):
        """Выход из редактора (Escape)"""
        # Если есть открытые диалоги - закрываем их
        if len(self.screen_stack) > 1:
            self.pop_screen()
            return
        # Если открыт поиск - закрываем поиск
        if self.search_visible:
            self.action_toggle_search()
            return
        # Если есть несохранённые изменения - показываем диалог подтверждения
        if self.has_unsaved_changes:
            self.push_screen(ConfirmDialog("Unsaved changes! Save before exit?"))
            return
        # Иначе - выходим из программы
        self.exit()

    def action_insert_tab(self):
        """Вставить табуляцию (4 пробела)"""
        self.editor.insert("    ")

    # -------------------------------------------------------------------------
    # Инициализация
    # -------------------------------------------------------------------------

    def __init__(self):
        super().__init__()
        self.current_file_path = None  # Путь к текущему файлу
        self.file_content = ""  # Содержимое текущего файла
        self.previous_file_path = None  # Путь к предыдущему файлу
        self.previous_file_content = ""  # Содержимое предыдущего файла
        self.search_visible = False  # Видимость панели поиска
        self._dialog_result = None  # Результат диалога открытия/сохранения
        self._confirm_result = None  # Результат диалога подтверждения
        self._startup_content = None  # Содержимое для автозагрузки
        self._startup_file_path = None  # Путь для автозагрузки

    # -------------------------------------------------------------------------
    # Создание интерфейса (compose)
    # -------------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        """Создание элементов интерфейса редактора"""
        yield Static("No file", id="filepath")  # Панель пути файла
        yield TextArea(show_line_numbers=True, id="editor")  # Текстовая область с номерами строк
        yield Static(id="search-bar")  # Панель поиска (скрыта по умолчанию)
        yield Footer()  # Нижняя панель с подсказками

    def on_mount(self):
        """Действия при запуске приложения"""
        self.editor = self.query_one("#editor", TextArea)
        self.filepath_display = self.query_one("#filepath", Static)
        self.search_bar = self.query_one("#search-bar", Static)
        self.search_bar.display = False  # Скрываем панель поиска
        
        # Если передан файл при запуске - загружаем его
        if self._startup_content is not None:
            self.editor.load_text(self._startup_content)
            self.current_file_path = self._startup_file_path
            self.file_content = self._startup_content
            self.update_title()

    # -------------------------------------------------------------------------
    # Обновление заголовка
    # -------------------------------------------------------------------------

    def update_title(self):
        """Обновить строку с путём файла"""
        path = self.current_file_path or "Untitled"
        marking = " *" if self.has_unsaved_changes else ""  # * если есть несохранённые изменения
        self.filepath_display.update(f"File: {path}{marking}")

    @property
    def has_unsaved_changes(self) -> bool:
        """Проверка: есть ли несохранённые изменения"""
        return self.editor.text != self.file_content

    # -------------------------------------------------------------------------
    # Стандартные действия TextArea
    # -------------------------------------------------------------------------

    def action_select_all(self):
        """Выделить всё (стандартное действие)"""
        self.editor.select_all()

    def action_undo(self):
        """Отменить действие (Ctrl+Z)"""
        self.editor.undo()

    def action_redo(self):
        """Повторить действие (Ctrl+Y)"""
        self.editor.redo()

    # -------------------------------------------------------------------------
    # Поиск
    # -------------------------------------------------------------------------

    def action_toggle_search(self):
        """Включить/выключить режим поиска (Ctrl+F)"""
        # Удаляем старые элементы из панели поиска
        for child in list(self.search_bar.children):
            child.remove()
        
        if self.search_visible:
            # Если поиск был открыт - закрываем
            self.search_visible = False
            self.search_bar.display = False
            self.editor.focus()
        else:
            # Открываем панель поиска
            self.search_visible = True
            self.search_bar.update("Search: ")
            self.search_bar.display = True
            search_input = Input(placeholder="Search...")
            self.search_bar.mount(search_input)
            search_input.focus()
        return True

    def on_input_changed(self, event):
        """Обработка изменения текста в поле поиска (real-time поиск)"""
        if self.search_visible and event.input:
            text = event.value
            if text:
                content = self.editor.text
                pos = content.lower().find(text.lower())
                if pos >= 0:
                    # Конвертируем позицию в формат Location (строка, колонка)
                    doc = self.editor.document
                    start = doc.get_location_from_index(pos)
                    end = doc.get_location_from_index(pos + len(text))
                    self.editor.selection = (start, end)

    def on_input_submitted(self, event):
        """Обработка нажатия Enter в поле поиска - закрываем поиск"""
        if self.search_visible:
            self.search_bar.display = False
            self.search_visible = False
            for child in list(self.search_bar.children):
                child.remove()
            self.editor.focus()

    # -------------------------------------------------------------------------
    # Открытие и сохранение ��айлов
    # -------------------------------------------------------------------------

    def action_open_file(self):
        """Открыть файл (Ctrl+O)"""
        self.push_screen(InputDialog("open"))
        return True

    def action_save_file(self):
        """Сохранить файл (Ctrl+S)"""
        self.push_screen(InputDialog("save", self.current_file_path or ""))
        return True

    def _handle_dialog_result(self):
        """Обработка результата диалога открытия/сохранения"""
        dialog = self._dialog_result
        if not dialog:
            return
        self._dialog_result = None
        path, mode = dialog
        
        if mode == "open":
            # Открытие файла
            # Сохраняем текущий как предыдущий
            if self.current_file_path:
                self.previous_file_path = self.current_file_path
                self.previous_file_content = self.file_content
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                self.editor.load_text(content)
                self.current_file_path = path
                self.file_content = content
                self.update_title()
            except Exception as e:
                self.notify(f"Error: {e}")
        else:
            # Сохранение файла
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(self.editor.text)
                self.current_file_path = path
                self.file_content = self.editor.text
                self.notify(f"Saved: {path}")
                self.update_title()
            except Exception as e:
                self.notify(f"Error: {e}")

    # -------------------------------------------------------------------------
    # Обработка результата диалога подтверждения
    # -------------------------------------------------------------------------

    def _handle_confirm_result(self):
        """Обработка выбора в диалоге подтверждения (Yes/No)"""
        result = self._confirm_result
        self._confirm_result = None
        
        if result == "save":
            # Сохраняем и выходим
            if self.current_file_path:
                try:
                    with open(self.current_file_path, "w", encoding="utf-8") as f:
                        f.write(self.editor.text)
                    self.file_content = self.editor.text
                    self.notify("Saved!")
                except Exception as e:
                    self.notify(f"Error: {e}")
                    return
            else:
                # Если путь не задан - открываем диалог сохранения
                self.push_screen(InputDialog("save"))
                return
            self.exit()
        elif result == "quit":
            # Просто выходим без сохранения
            self.exit()

    # -------------------------------------------------------------------------
    # События
    # -------------------------------------------------------------------------

    def on_text_area_changed(self, event: TextArea.Changed):
        """Обновляем заголовок при изменении текста"""
        self.update_title()


# ============================================================================
# Запуск приложения
# ============================================================================
if __name__ == "__main__":
    import sys
    
    app = EditorApp()
    
    # Если передан путь к файлу как аргумент командной строки - открываем его
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            app._startup_content = content
            app._startup_file_path = file_path
        except:
            pass
    
    app.run()