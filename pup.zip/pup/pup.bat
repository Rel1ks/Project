@echo off 
python "C:\Users\FSOS\Documents\pup\editor.py" %* 
