@echo off
REM Uninstall pup command

del "%TEMP%\pup.bat" 2>nul
del "%~dp0pup.bat" 2>nul

echo.
echo ========================================
echo   pup command uninstalled!
echo.
echo   NOTE: Remove these from PATH manually:
echo   - %%TEMP%%
echo   - C:\Users\FSOS\Documents\pup
echo.
pause